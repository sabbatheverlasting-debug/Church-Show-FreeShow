SÅNGSTUND – CHURCH SHOW PRO 2

Installera ZIP-filen via Arkiv > Importera > Gemensam import.
Bakgrunder: Media > Sångstund. Sångmallar: Templates > Sång.
Programteman: Inställningar > Tema. Välj önskat tema efter installation.

Bakgrunder i SVG (3840 × 2160) och matchande sångmallar.
Den gamla provversionen från 13 november saknar denna nya paketadapter.
Använd Church Show Pro 2 version 2.0.3 eller senare.

Gemensamt format churchshow-style-pack v1. Mobilappar behöver en adapter
för samma format; mobilstöd är inte implementerat i detta paket.
Inga personliga filer, fotografier eller externa resurser ingår.
